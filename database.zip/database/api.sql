-- CREATE ROLE viyk WIEH LOGIN PASSWORD '24601';
-- ALTER ROLE viyk CREATEDB;
-- psql -d postgres -U viyk
-- CREATE DATABASE api;
-- \l;
-- \c api;

-- 用户
-- 与小组多对多（中间表 user_group）
-- 与标注一对多
-- 与评论一对多
CREATE TABLE users (
  ID SERIAL PRIMARY KEY,
  name VARCHAR(30),
  display_name VARCHAR(30),
  email VARCHAR(30) UNIQUE,
  email_status BOOLEAN DEFAULT false,
  password VARCHAR(30),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
insert into users (name, display_name, email, password) values ('viyk', 'VK', 'v@k.com', 'hjkl');
alter table users add column email_status boolean default false;
alter table users add column bio text;
alter table users add column avatar_url text;


-- 小组
-- 与标注一对多
CREATE TABLE groups (
  ID SERIAL PRIMARY KEY,
  name VARCHAR(30),
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
insert into groups (name,description) values ('National Study Center','国家学习中心');
insert into groups (name,description) values ('Geeks Republic','Of the geeks, by the geeks, for the geeks.');

-- 用户-小组中间表
-- type: 组长，管理员，普通成员
CREATE TABLE user_group (
  ID SERIAL PRIMARY KEY,
  user_id INT NOT NULL references users,
  group_id INT NOT NULL references groups,
  user_type VARCHAR(30) NOT NULL
);
insert into user_group (user_id,group_id,user_type) values (1,2,'组长');
insert into user_group (user_id,group_id,user_type) values (3,2,'管理员');
insert into user_group (user_id,group_id,user_type) values (4,2,'组员');
insert into user_group (user_id,group_id,user_type) values (4,3,'组长');

-- 标注
-- 与评论一对多
CREATE TABLE annotations (
  ID SERIAL PRIMARY KEY,
  uri VARCHAR(30),
  content TEXT,
  group_id INT references groups,
  user_id INT references users,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP
);

--评论
CREATE TABLE comments (
  ID SERIAL PRIMARY KEY,
  content TEXT,
  user_id INT references users,
  anno_id INT references annotations,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP
);

-- 测试数据库
CREATE TABLE notes (
    id SERIAL PRIMARY KEY,
    content text NOT NULL,
    important boolean,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
insert into notes (content, important) values ('Relational databases rule the world', true);
insert into notes (content, important) values ('MongoDB is webscale', false);
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.12
-- Dumped by pg_dump version 14.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: viyk
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(30) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.groups OWNER TO viyk;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: viyk
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO viyk;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: viyk
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: viyk
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    content text NOT NULL,
    important boolean,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.notes OWNER TO viyk;

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: viyk
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notes_id_seq OWNER TO viyk;

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: viyk
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: user_group; Type: TABLE; Schema: public; Owner: viyk
--

CREATE TABLE public.user_group (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    user_type character varying(30) NOT NULL
);


ALTER TABLE public.user_group OWNER TO viyk;

--
-- Name: user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: viyk
--

CREATE SEQUENCE public.user_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_group_id_seq OWNER TO viyk;

--
-- Name: user_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: viyk
--

ALTER SEQUENCE public.user_group_id_seq OWNED BY public.user_group.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: viyk
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(30),
    display_name character varying(30),
    email character varying(30),
    password character varying(30),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email_status boolean DEFAULT false,
    bio text,
    avatar_url text
);


ALTER TABLE public.users OWNER TO viyk;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: viyk
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO viyk;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: viyk
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: user_group id; Type: DEFAULT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.user_group ALTER COLUMN id SET DEFAULT nextval('public.user_group_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: viyk
--

COPY public.groups (id, name, description, created_at) FROM stdin;
2	National Study Center	国家学习中心	2022-09-04 15:45:51.538363+08
3	Geeks Republic	Of the geeks, by the geeks, for the geeks.	2022-09-04 22:08:36.632967+08
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: viyk
--

COPY public.notes (id, content, important, created_at) FROM stdin;
\.


--
-- Data for Name: user_group; Type: TABLE DATA; Schema: public; Owner: viyk
--

COPY public.user_group (id, user_id, group_id, user_type) FROM stdin;
3	3	2	管理员
5	4	3	组长
17	1	2	组长
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: viyk
--

COPY public.users (id, name, display_name, email, password, created_at, email_status, bio, avatar_url) FROM stdin;
6	sss	Snake		sss	2022-09-09 12:41:40.78+08	f	\N	\N
7	django	DJ		python	2022-09-09 13:37:36.647+08	f	\N	\N
3	Alice	文艳	y.qgqlwk@djpxl.ar	SuqK	2022-09-03 15:21:59.881+08	f	Very Good	\N
4	viyk	VK	v@k.com	hjkl	2022-09-04 22:09:24.953608+08	t	I am VK.	\N
1	jojo	JoJo	xiaohuabeta@gmail.com	hjkl	2022-09-03 14:38:30.530142+08	t	Jolyne!!	\N
\.


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: viyk
--

SELECT pg_catalog.setval('public.groups_id_seq', 3, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: viyk
--

SELECT pg_catalog.setval('public.notes_id_seq', 1, false);


--
-- Name: user_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: viyk
--

SELECT pg_catalog.setval('public.user_group_id_seq', 17, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: viyk
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: users some_name; Type: CONSTRAINT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT some_name UNIQUE (name);


--
-- Name: user_group user_group_pkey; Type: CONSTRAINT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: user_group user_group_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: user_group user_group_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: viyk
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

